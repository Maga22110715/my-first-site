import { getEl } from './functions.js';

function saveData() {
    let arrItems = [];
    let arrDone = [];

    let list = getEl('.todo-list');
    let items = list.querySelectorAll('.todo-list__item');
    let texts = document.querySelectorAll('.text');

    for (let i = 0; i < items.length; i++) {
        arrItems.push(items[i].textContent);
    }

    texts.forEach(el => {
        arrDone.push(el.classList.contains('done'));
    });

    localStorage.setItem('items', JSON.stringify(arrItems));
    localStorage.setItem('classes', JSON.stringify(arrDone));
}

export { saveData }